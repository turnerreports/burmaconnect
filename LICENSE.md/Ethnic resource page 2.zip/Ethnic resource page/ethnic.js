$(document).ready(function () {
	/*function used in several places to show slide info*/
	var showInfo = function () {
		$('.circle').addClass('hide_btn'); /*.circle so it closes all circles.*/
		$('#X-close').addClass('btn_close_show');
		// $('.info_slides').addClass('info_slides_show');
		// $('#nyc-info').addClass('nyc_show');
		// $('#utica-info').addClass('utica_show');
	}

	/*New York info*/
	$('#circle_new-york').click(function () {
		showInfo();
		$('#nyc-info').addClass('nyc_show');
		// $('#nyc-info').addClass('info_slides_show');
		// .text('New York City').addClass('popIn-info')
	});


	/*Utica info*/
	$('#circle_utica').click(function () {
		showInfo();
		$('#utica-info').addClass('utica_show');
	});

/*Buffalo info*/
	$('#circle_buffalo').click(function () {
		showInfo();
		$('#buffalo-info').addClass('buffalo_show');
	});

/*Syracuse info*/
		$('#circle_syracuse').click(function () {
			showInfo();
			$('#syracuse-info').addClass('syracuse_show');
		});

/*Albany info*/
		$('#circle_albany').click(function () {
			showInfo();
			$('#albany-info').addClass('albany_show');
		});


	/*close info window*/

	$('#X-close').click(function () {
		$('#X-close').removeClass('btn_close_show'); /* hide close X*/
		$('.info_slides').removeClass('nyc_show utica_show syracuse_show albany_show buffalo_show');
		// $('.info_slides').removeClass('info_slides_show'); /*remove info window*/
		/*dont' seem to need to remove popIn-info*/
		$('.circle').removeClass('hide_btn'); /*show circles*/


	});

});
